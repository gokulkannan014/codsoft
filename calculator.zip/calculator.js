document.addEventListener('DOMContentLoaded', () => {
    const calculatorScreen = document.getElementById('calculator-screen');
    const keys = document.querySelector('.calculator-keys');
    let currentInput = '';
    let previousInput = '';
    let operator = '';

    keys.addEventListener('click', event => {
        const { target } = event;
        const { value } = target;
        if (!target.matches('button')) {
            return;
        }

        switch (value) {
            case '+':
            case '-':
            case '*':
            case '/':
                handleOperator(value);
                break;
            case '=':
                calculate();
                break;
            case 'C':
                clear();
                break;
            default:
                inputNumber(value);
        }

        updateScreen();
    });

    function handleOperator(nextOperator) {
        const inputValue = parseFloat(currentInput);

        if (operator && previousInput) {
            calculate();
        } else {
            previousInput = inputValue;
        }

        operator = nextOperator;
        currentInput = '';
    }

    function calculate() {
        let result;
        const prev = parseFloat(previousInput);
        const current = parseFloat(currentInput);

        if (isNaN(prev) || isNaN(current)) {
            return;
        }

        switch (operator) {
            case '+':
                result = prev + current;
                break;
            case '-':
                result = prev - current;
                break;
            case '*':
                result = prev * current;
                break;
            case '/':
                result = prev / current;
                break;
            default:
                return;
        }

        currentInput = result;
        operator = '';
        previousInput = '';
    }

    function inputNumber(number) {
        currentInput = currentInput === '' ? number : currentInput + number;
    }

    function clear() {
        currentInput = '';
        previousInput = '';
        operator = '';
    }

    function updateScreen() {
        calculatorScreen.value = currentInput;
    }
});
